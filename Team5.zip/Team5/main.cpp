#include<stdio.h>
#include<stdlib.h>
#include<GL/glut.h>
#include<string.h>
#include<math.h>
#define WINNING_SCORE 150
#define row 10
#define col 20

int placement[row][col];
int enem_dir[row][col];  //enem_dir store current direction of enemy at their index value
int enem_hist[row][col]; //enem_hist store if enemy have already moved.
int player_x, player_y;
int score = 0;
char player_direction = 'r'; // Tracks player's facing direction

int paused = 0;
int game_over=0;
int game_won=0;

/*
    -2 indicates horizontal walls
    -1 indicates vertical walls
    0 indicates neutral
    1 indicates food
    2 indicates enemies
    3 indicate player

*/
void initialize_pos()
{
    // Initialize all cells as food (1) first
    for (int i = 0; i < row; i++)
        for (int j = 0; j < col; j++) {
            placement[i][j] = 1;
            enem_dir[i][j] = 0;
            enem_hist[i][j] = 0;
        }

    // Player starting position
    placement[1][1] = 3;
    player_x = 1;
    player_y = 1;
    
    // Enemy setup - fewer enemies but strategically placed
    placement[4][11] = 2;
    placement[7][5] = 2;
    placement[2][15] = 2;

    enem_dir[4][11] = 'u';
    enem_dir[7][5] = 'r';
    enem_dir[2][15] = 'l';
    
    // New Maze Design - more complex with corridors
    // Outer walls
    for(int i = 0; i < row; i++) {
        placement[i][0] = -1;       // Left wall
        placement[i][col-1] = -1;   // Right wall
    }
    for(int j = 0; j < col; j++) {
        placement[0][j] = -2;       // Bottom wall
        placement[row-1][j] = -2;   // Top wall
    }

    // Inner walls - creating a more interesting maze
    // Vertical walls
    for(int i = 1; i < 5; i++) {
        placement[i][4] = -1;
        placement[i][8] = -1;
        placement[i][12] = -1;
        placement[i][16] = -1;
    }
    for(int i = 5; i < 9; i++) {
        placement[i][6] = -1;
        placement[i][10] = -1;
        placement[i][14] = -1;
    }

    // Horizontal walls
    for(int j = 2; j < 7; j++) {
        placement[3][j] = -2;
        placement[6][j] = -2;
    }
    for(int j = 13; j < 18; j++) {
        placement[3][j] = -2;
        placement[6][j] = -2;
    }

    // Special gates that allow passage
    placement[0][9] = 1;    // Top gate
    placement[9][9] = 1;    // Bottom gate
    placement[4][0] = 1;    // Left gate
    placement[4][col-1] = 1; // Right gate
    
	placement[7][6] = 1;
    placement[2][2] = 0;
    placement[2][16] = 1;
    placement[7][2] = 0;
    placement[7][17] = 0;
    placement[4][5] = 0;
    placement[5][14] = 0;
}
int isGate(int y, int x) {
    // Check if the position is one of the gate positions
    return (y == 9 && x == 9) ||  // upper gate
           (y == 0 && x == 9) ||   // lower gate
           (y == 4 && x == 0) ||   // left gate
           (y == 4 && x == 19);    // right gate
}

void gameOver()
{
    paused=1;
    game_over=1;
    glRasterPos2f(47, 6 * 6);
    char *k = " G A M E -  O V E R ";
    for (int i = 0; i < strlen(k); i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, k[i]);

    //Score Part
    char *s="Press R to Restart";
    glRasterPos2f(6 * 8, 5 * 6);
    int t=strlen(s);
    for (int i = 0; i < t; i++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[i]);
    return;
}

void gameWon()
{
    paused=1;
    game_won=1;
    game_over=1;
    glRasterPos2f(47, 6 * 6);
    char *k = " Y O U -  W O N !!!!!! ";
    for (int i = 0; i < strlen(k); i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, k[i]);

    //Score Part
    char *s="Press R to Replay";
    glRasterPos2f(6 * 8, 5 * 6);
    int t=strlen(s);
    for (int i = 0; i < t; i++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[i]);
    return;
}

void restartGame(){
    initialize_pos();
    game_over=0;
    paused=0;
    score=0;
    game_won=0;
}

void moveEnemy(int i, int j)
{
    if (enem_dir[i][j] == 'r')
    {
        if ((j + 1) < col && placement[i][j + 1] >= 0)
        {
            if (placement[i][j + 1] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 0;
            placement[i][j + 1] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i][j + 1] = 'r';
            enem_hist[i][j + 1] = 1;
        }
        else
        {
            if (placement[i][j - 1] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 1;
            placement[i][j - 1] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i][j - 1] = 'l';
            enem_hist[i][j - 1] = 1;
        }
    }
    else if (enem_dir[i][j] == 'l')
    {
        if ((j - 1) >= 0 && placement[i][j - 1] >= 0)
        {
            if (placement[i][j - 1] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 1;
            placement[i][j - 1] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i][j - 1] = 'l';
            enem_hist[i][j - 1] = 1;
        }
        else
        {
            if (placement[i][j + 1] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 1;
            placement[i][j + 1] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i][j + 1] = 'r';
            enem_hist[i][j + 1] = 1;
        }
    }
    else if (enem_dir[i][j] == 'u')
    {
        if ((i + 1) < row && placement[i + 1][j] >= 0)
        {
            if (placement[i + 1][j] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 1;
            placement[i + 1][j] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i + 1][j] = 'u';
            enem_hist[i + 1][j] = 1;
        }
        else
        {
            if (placement[i - 1][j] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 1;
            placement[i - 1][j] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i - 1][j] = 'd';
            enem_hist[i - 1][j] = 1;
        }
    }
    else if (enem_dir[i][j] == 'd')
    {
        if ((i - 1) >= 0 && placement[i - 1][j] >= 0)
        {
            if (placement[i - 1][j] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 1;
            placement[i - 1][j] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i - 1][j] = 'd';
            enem_hist[i - 1][j] = 1;
        }
        else
        {
            if (placement[i + 1][j] == 3)
            {
                gameOver();
                return;
            }
            placement[i][j] = 1;
            placement[i + 1][j] = 2;
            enem_dir[i][j] = 0;
            enem_dir[i + 1][j] = 'u';
            enem_hist[i + 1][j] = 1;
        }
    }
    else if (enem_dir[i][j] == 0)
    {
        enem_dir[i][j] == 'u';
    }

    glutPostRedisplay();
}

void moveEnemies(int value)
{
    if (paused == 0)
    {
        for (int i = 0; i < row; i++)
            for (int j = 0; j < col; j++)
                enem_hist[i][j] = 0;

        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                if (placement[i][j] == 2 && enem_hist[i][j] == 0)
                {
                    moveEnemy(i, j);
                }
            }
        }
    }
    glutPostRedisplay(); 
    glutTimerFunc(300, moveEnemies, 0);
}

void showPlayer(int i, int j) {
    glColor3f(1.0, 1.0, 0.0); // Yellow
    
    float centerX = 6 * j + 3;
    float centerY = 6 * i + 3;
    float radius = 2.5;
    
    // Mouth angles based on direction - properly fixed
    float start_angle, end_angle;
    switch(player_direction) {
        case 'u': // Up
            start_angle = 45;
            end_angle = 315;  // 270 degree mouth opening facing up
            break;
        case 'd': // Down
            start_angle = 225;
            end_angle = 495;  // 270 degree mouth opening facing down (using >360)
            break;
        case 'l': // Left
            start_angle = 135;
            end_angle = 405;  // 270 degree mouth opening facing left (using >360)
            break;
        case 'r': // Right
        default:
            start_angle = 315;
            end_angle = 585;  // 270 degree mouth opening facing right (using >360)
            break;
    }
    
    // Draw Pac-Man with properly rotated mouth
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(centerX, centerY); // Center point
    
    // Draw the full circle minus the mouth opening
    for (int angle = (int)start_angle; angle <= (int)end_angle; angle += 5) {
        float rad = angle * M_PI / 180.0;
        glVertex2f(centerX + radius * cos(rad), 
                  centerY + radius * sin(rad));
    }
    glEnd();
    
    // Draw eye - position based on direction
    glColor3f(0.0, 0.0, 0.0); // Black eye
    float eyeX = centerX, eyeY = centerY;
    
    switch(player_direction) {
        case 'u': // Up
            eyeX -= 0.9;
            eyeY += 0.9;
            break;
        case 'd': // Down
            eyeX += 0.7;
            eyeY += 0.7;
            break;
        case 'l': // Left
            eyeX -= 1.5;
            eyeY += 0.3;
            break;
        case 'r': // Right
            eyeX -= 0.7;
            eyeY += 0.9;
            break;
    }
    
    glPointSize(4);
    glBegin(GL_POINTS);
    glVertex2f(eyeX, eyeY);
    glEnd();
}

void showEnemy(int i, int j) {
    float x = 6 * j + 3;
    float y = 6 * i + 3;
    float size = 2.5;
    
    // Main body
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_QUADS);
    glVertex2f(x - size, y - size);
    glVertex2f(x + size, y - size);
    glVertex2f(x + size, y + size);
    glVertex2f(x - size, y + size);
    glEnd();
    
    // Bottom waves
    glBegin(GL_TRIANGLES);
    glVertex2f(x - size, y - size);
    glVertex2f(x - size + 1.6, y - size - 1.0);
    glVertex2f(x - size + 3.3, y - size);
    
    glVertex2f(x - size + 1.6, y - size);
    glVertex2f(x - size + 3.3, y - size - 1.0);
    glVertex2f(x - size + 5.0, y - size);
    glEnd();
    
    // Eyes
    glColor3f(1.0, 1.0, 1.0);
    float eye_offset_x = 0.0, eye_offset_y = 0.0;
    
    switch(enem_dir[i][j]) {
        case 'u': eye_offset_y = 0.3; break;
        case 'd': eye_offset_y = -0.3; break;
        case 'l': eye_offset_x = -0.3; break;
        case 'r': eye_offset_x = 0.3; break;
    }
    
    glBegin(GL_QUADS);
    // Left eye
    glVertex2f(x - 1.0 + eye_offset_x, y + 0.5 + eye_offset_y);
    glVertex2f(x - 0.3 + eye_offset_x, y + 0.5 + eye_offset_y);
    glVertex2f(x - 0.3 + eye_offset_x, y + 1.5 + eye_offset_y);
    glVertex2f(x - 1.0 + eye_offset_x, y + 1.5 + eye_offset_y);
    // Right eye
    glVertex2f(x + 0.3 + eye_offset_x, y + 0.5 + eye_offset_y);
    glVertex2f(x + 1.0 + eye_offset_x, y + 0.5 + eye_offset_y);
    glVertex2f(x + 1.0 + eye_offset_x, y + 1.5 + eye_offset_y);
    glVertex2f(x + 0.3 + eye_offset_x, y + 1.5 + eye_offset_y);
    glEnd();
    
    // Pupils
    glColor3f(0.0, 0.0, 1.0);
    glPointSize(4);
    glBegin(GL_POINTS);
    glVertex2f(x - 0.7 + eye_offset_x*2, y + 1.0 + eye_offset_y*2);
    glVertex2f(x + 0.7 + eye_offset_x*2, y + 1.0 + eye_offset_y*2);
    glEnd();
}

void showFood(int i, int j)
{
    glPointSize(2);
    glColor3f(0.5, 0.5, 1.0);
    glBegin(GL_POINTS);
    glVertex2d(j * 6 + 2, i * 6 + 2);
    glEnd();
}

void showWall(int i, int j)
{
    glColor3f(1, 1, 0);
    if (placement[i][j] == -1)
    {
        glLineWidth(10);
        glBegin(GL_LINES);
        glVertex2d(j * 6 + 3, i * 6 + 1);
        glVertex2d(j * 6 + 3, (i + 1) * 6 - 1);
        glEnd();
    }
    else
    {
        glLineWidth(10);
        glBegin(GL_LINES);
        glVertex2d(j * 6 + 3, i * 6 + 3);
        glVertex2d((j + 1) * 6, i * 6 + 3);
        glEnd();
    }
}

void showScoreBoard()
{
    //Title
    glRasterPos2f(47, 11 * 6);
    char *k = " P A C M A N ";
    for (int i = 0; i < strlen(k); i++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, k[i]);

    //Score Part
    char s[15] = {'S', 'C', 'O', 'R', 'E', ':', ' '};
    sprintf(s + 7, "%d", score);
    int t = strlen(s);
    glRasterPos2f(6 * 8, 10 * 6);
    for (int i = 0; i < t; i++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[i]);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            if (placement[i][j] == 1)
            {
                showFood(i, j);
            }
            else if (placement[i][j] == 3)
            {
                showPlayer(i, j);
            }
            else if (placement[i][j] == 2)
            {
                showEnemy(i, j);
            }
            else if (placement[i][j] == -1 || placement[i][j] == -2)
            {
                showWall(i, j);
            }
        }
    }
    if(game_over){
        if(game_won)
            gameWon();
        else
            gameOver();
    }
    showScoreBoard();
    glFlush();
}

void init()
{
    glViewport(0, 0, 500, 500);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 120.0, 0, 70.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glColor3f(0.5, 0.5, 1.0);
    moveEnemies(0);
}

void mykeys(unsigned char key, int x, int y)
{
    
    if (game_over && key == 'r') {
        restartGame();
        return;
    }

    if (paused && key == 'r') {
        paused = 0;
        return;
    }

    if (paused) {
        return;
    }

    switch (key) {
    case 'p':
        paused = 1;
        break;
    case 'w': // Move up
    	player_direction = 'l';
        if (player_y + 1 < row && (placement[player_y + 1][player_x] >= 0 || isGate(player_y + 1, player_x))) {
            if (placement[player_y + 1][player_x] == 1) {
                score++;
            } else if (placement[player_y + 1][player_x] == 2) {
                gameOver();
                return;
            }    
            placement[player_y][player_x] = 0;
            player_y++;
            placement[player_y][player_x] = 3;
            
            // Check if we're going through the top gate
            if (player_y == 9 && player_x == 9) {
                placement[player_y][player_x] = 0; // Clear current position
                player_y = 0; // Wrap to bottom
                player_x = 9;
                placement[player_y][player_x] = 3;
            }
        }
        break;
    case 's': // Move down
    	player_direction = 'r';
        if (player_y - 1 >= 0 && (placement[player_y - 1][player_x] >= 0 || isGate(player_y - 1, player_x))) {
            if (placement[player_y - 1][player_x] == 1) {
                score++;
            } else if (placement[player_y - 1][player_x] == 2) {
                gameOver();
                return;
            }
            placement[player_y][player_x] = 0;
            player_y--;
            placement[player_y][player_x] = 3;
            
            // Check if we're going through the bottom gate
            if (player_y == 0 && player_x == 9) {
                placement[player_y][player_x] = 0; // Clear current position
                player_y = 9; // Wrap to top
                player_x = 9;
                placement[player_y][player_x] = 3;
            }
        }
        break;
    case 'a': // Move left
    	player_direction = 'd';
        if (player_x - 1 >= 0 && (placement[player_y][player_x - 1] >= 0 || isGate(player_y, player_x - 1))) {
            if (placement[player_y][player_x - 1] == 1) {
                score++;
            } else if (placement[player_y][player_x - 1] == 2) {
                gameOver();
                return;
            }
            placement[player_y][player_x] = 0;
            player_x--;
            placement[player_y][player_x] = 3;
            
            // Check if we're going through the left gate
            if (player_y == 4 && player_x == 0) {
                placement[player_y][player_x] = 0; // Clear current position
                player_y = 4; 
                player_x = 19; // Wrap to right
                placement[player_y][player_x] = 3;
            }
        }
        break;
    case 'd': // Move right
        player_direction = 'u';
        if (player_x + 1 < col && (placement[player_y][player_x + 1] >= 0 || isGate(player_y, player_x + 1))) {
            if (placement[player_y][player_x + 1] == 1) {
                score++;
            } else if (placement[player_y][player_x + 1] == 2) {
                gameOver();
                return;
            }
            placement[player_y][player_x] = 0;
            player_x++;
            placement[player_y][player_x] = 3;
            
            // Check if we're going through the right gate
            if (player_y == 4 && player_x == 19) {
                placement[player_y][player_x] = 0; // Clear current position
                player_y = 4;
                player_x = 0; // Wrap to left
                placement[player_y][player_x] = 3;
            }
        }
        break;
    }

    if (score >= WINNING_SCORE) {
        gameWon();
    }

    glutPostRedisplay();
}

int main(int argc, char **argv)
{
    initialize_pos();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
    glutInitWindowSize(1200, 600);
    glutCreateWindow("Pacman");
    glutDisplayFunc(display);
    glutKeyboardFunc(mykeys);
    
    init();
    glutMainLoop();
    return 0;
}

